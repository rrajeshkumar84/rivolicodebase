namespace Andy.Guard.Scanning.Configuration;

/// <summary>
/// Configuration for the heuristic engine loaded from JSON
/// </summary>
public class HeuristicConfiguration
{
    public List<ModelConfiguration> Models { get; set; } = new();
    public EngineSettings Settings { get; set; } = new();
}

/// <summary>
/// Configuration for a specific model and its heuristic rules
/// </summary>
public class ModelConfiguration
{
    public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public int Priority { get; set; }
    public bool Enabled { get; set; } = true;
    public HeuristicRules Heuristics { get; set; } = new();
}

/// <summary>
/// Heuristic rules for detecting if a prompt should use a specific model
/// </summary>
public class HeuristicRules
{
    public List<string> Keywords { get; set; } = new();
    public List<string> Patterns { get; set; } = new();
    public int MinimumMatches { get; set; } = 1;
    public double ConfidenceWeight { get; set; } = 1.0;
}

/// <summary>
/// Global settings for the heuristic engine
/// </summary>
public class EngineSettings
{
    public string DefaultModel { get; set; } = "deberta";
    public double MinimumConfidenceThreshold { get; set; } = 0.3;
    public bool CaseSensitive { get; set; } = false;
    public bool EnablePatternMatching { get; set; } = true;
}