﻿# Heuristic Engine Files

This zip contains all the files for the JSON-configured heuristic engine.

## Files Included:

### Core Implementation
- src/Andy.Guard/Scanning/JsonHeuristicEngine.cs (Main engine class)
- src/Andy.Guard/Scanning/Configuration/HeuristicConfiguration.cs (Configuration models)
- src/Andy.Guard/Scanning/heuristic-config.json (JSON configuration)

### Examples & Documentation  
- examples/JsonHeuristicEngineExample.cs (Usage example)
- docs/JSON_HEURISTIC_ENGINE.md (Complete documentation)

## Installation:
1. Copy files to your Andy.Guard project maintaining folder structure
2. Add System.Text.Json NuGet package reference
3. Update .csproj to copy heuristic-config.json to output

## Usage:
`csharp
var engine = new JsonHeuristicEngine("heuristic-config.json");
string model = engine.GetRecommendedModel("your prompt here");
`

Created: 10/22/2025 10:56:25
