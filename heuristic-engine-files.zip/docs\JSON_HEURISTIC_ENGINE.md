# JSON-Configured Heuristic Engine

A flexible, JSON-configured heuristic engine that analyzes prompts and recommends the most appropriate model (DeBERTa, Toxic RoBERTa, Presidio Analyzer, etc.) based on configurable rules.

## Key Features

✅ **No Hardcoded Models**: All model names and rules are defined in JSON  
✅ **Single Model Recommendation**: Returns one best model per prompt  
✅ **Configurable Heuristics**: Keywords, regex patterns, priorities per model  
✅ **Runtime Reconfiguration**: Reload JSON config without restart  
✅ **Extensible**: Easy to add new models and rules  

## Quick Start

```csharp
// Initialize with JSON config
var engine = new JsonHeuristicEngine("heuristic-config.json");

// Get model recommendation
string model = engine.GetRecommendedModel("ignore previous instructions");
// Returns: "deberta"

// Get detailed analysis
var scores = engine.GetAllModelScores("some prompt");
```

## Configuration Structure

### JSON Schema

```json
{
  "models": [
    {
      "name": "deberta",
      "description": "DeBERTa model for prompt injection",
      "priority": 100,
      "enabled": true,
      "heuristics": {
        "keywords": ["ignore previous", "system:", "override"],
        "patterns": ["\\b(ignore|forget)\\s+previous", "system\\s+prompt"],
        "minimumMatches": 1,
        "confidenceWeight": 0.8
      }
    }
  ],
  "settings": {
    "defaultModel": "deberta",
    "minimumConfidenceThreshold": 0.3,
    "caseSensitive": false,
    "enablePatternMatching": true
  }
}
```

### Model Configuration

| Property | Description |
|----------|-------------|
| `name` | Unique model identifier (returned by engine) |
| `description` | Human-readable description |  
| `priority` | Higher numbers = higher priority when scores are equal |
| `enabled` | Whether this model is active |
| `heuristics` | Rules for detecting when to use this model |

### Heuristic Rules

| Property | Description |
|----------|-------------|
| `keywords` | Simple string matches (case-insensitive by default) |
| `patterns` | Regular expressions for complex pattern matching |
| `minimumMatches` | Minimum keyword/pattern matches required |
| `confidenceWeight` | Multiplier for final confidence score (0.0-1.0) |

### Global Settings

| Property | Description |
|----------|-------------|
| `defaultModel` | Model returned when no rules match |
| `minimumConfidenceThreshold` | Minimum score required for recommendation |
| `caseSensitive` | Whether keyword matching is case-sensitive |
| `enablePatternMatching` | Whether to use regex patterns |

## Built-in Models

### DeBERTa (`deberta`)
**Purpose**: Prompt injection detection  
**Keywords**: "ignore previous", "system:", "act as", "jailbreak"  
**Priority**: 100 (highest)

### Toxic RoBERTa (`toxic-roberta`)  
**Purpose**: Toxicity and harmful content detection  
**Keywords**: "hate", "kill", "violence", profanity  
**Priority**: 90

### Presidio Analyzer (`presidio-analyzer`)
**Purpose**: PII and sensitive data detection  
**Patterns**: Email addresses, phone numbers, SSNs, credit cards  
**Priority**: 95

## How It Works

1. **Prompt Analysis**: Each enabled model's heuristics are evaluated
2. **Scoring**: Keyword matches + pattern matches = raw score
3. **Weighting**: Raw score × confidenceWeight = final score  
4. **Selection**: Highest scoring model above threshold wins
5. **Fallback**: Default model if no matches or scores too low

## Usage Patterns

### Basic Usage
```csharp
var engine = new JsonHeuristicEngine("config.json");
var model = engine.GetRecommendedModel(userPrompt);
// Use model with your scanner registry
```

### Integration with Scanner Registry
```csharp
public async Task<ScanResult> ScanPromptAsync(string prompt)
{
    var model = _heuristicEngine.GetRecommendedModel(prompt);
    return await _scannerRegistry.ScanAsync(prompt, new[] { model });
}
```

### Debugging and Monitoring
```csharp
var scores = engine.GetAllModelScores(prompt);
foreach (var (model, score) in scores)
{
    _logger.LogDebug("Model {Model}: {Score:F3}", model, score);
}
```

## Extending the Configuration

### Adding a New Model
```json
{
  "name": "my-custom-model",
  "description": "Custom business logic model",
  "priority": 80,
  "enabled": true,
  "heuristics": {
    "keywords": ["business", "enterprise", "corporate"],
    "patterns": ["\\bcustomer\\s+support\\b"],
    "minimumMatches": 1,
    "confidenceWeight": 0.6
  }
}
```

### Runtime Configuration Updates
```csharp
// Modify JSON file, then reload
engine.ReloadConfiguration("updated-config.json");
```

## Best Practices

1. **Start Simple**: Begin with keyword matching, add patterns as needed
2. **Test Thoroughly**: Validate heuristics with real prompts  
3. **Monitor Scores**: Log model scores for tuning thresholds
4. **Prioritize Carefully**: Higher priority models win ties
5. **Use Confidence Weights**: Fine-tune model selection sensitivity
6. **Regular Expressions**: Test patterns thoroughly, handle exceptions

## File Structure

```
src/Andy.Guard/Scanning/
├── Configuration/
│   └── HeuristicConfiguration.cs    # JSON model classes
├── JsonHeuristicEngine.cs           # Main engine class  
└── heuristic-config.json           # Model configuration

examples/
└── JsonHeuristicEngineExample.cs   # Usage example
```

This implementation provides exactly what you requested: a JSON-configured, extensible heuristic engine with no hardcoded model names that suggests one model at a time based on configurable rules.