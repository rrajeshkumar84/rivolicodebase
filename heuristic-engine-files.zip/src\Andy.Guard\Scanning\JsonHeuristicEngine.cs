using System.Text.Json;
using System.Text.RegularExpressions;
using Andy.Guard.Scanning.Configuration;

namespace Andy.Guard.Scanning;

/// <summary>
/// JSON-configured heuristic engine that evaluates prompts and suggests the best model
/// </summary>
public class JsonHeuristicEngine
{
    private readonly HeuristicConfiguration _config;
    private readonly List<Regex> _compiledPatterns;

    public JsonHeuristicEngine(string configFilePath)
    {
        _config = LoadConfiguration(configFilePath);
        _compiledPatterns = CompilePatterns();
    }

    public JsonHeuristicEngine(HeuristicConfiguration configuration)
    {
        _config = configuration;
        _compiledPatterns = CompilePatterns();
    }

    /// <summary>
    /// Evaluates a prompt and returns the recommended model name
    /// </summary>
    /// <param name="prompt">The input prompt to analyze</param>
    /// <returns>The name of the recommended model</returns>
    public string GetRecommendedModel(string prompt)
    {
        if (string.IsNullOrWhiteSpace(prompt))
            return _config.Settings.DefaultModel;

        var modelScores = new List<ModelScore>();

        // Evaluate each enabled model
        foreach (var model in _config.Models.Where(m => m.Enabled))
        {
            var score = EvaluateModelMatch(prompt, model);
            if (score > 0)
            {
                modelScores.Add(new ModelScore
                {
                    ModelName = model.Name,
                    Score = score,
                    Priority = model.Priority
                });
            }
        }

        // Return highest scoring model, or default if none match
        if (modelScores.Count == 0)
            return _config.Settings.DefaultModel;

        // Sort by score first, then by priority
        var bestModel = modelScores
            .OrderByDescending(m => m.Score)
            .ThenByDescending(m => m.Priority)
            .First();

        return bestModel.Score >= _config.Settings.MinimumConfidenceThreshold 
            ? bestModel.ModelName 
            : _config.Settings.DefaultModel;
    }

    /// <summary>
    /// Gets detailed analysis of all models for debugging
    /// </summary>
    public Dictionary<string, double> GetAllModelScores(string prompt)
    {
        var scores = new Dictionary<string, double>();

        foreach (var model in _config.Models.Where(m => m.Enabled))
        {
            scores[model.Name] = EvaluateModelMatch(prompt, model);
        }

        return scores;
    }

    /// <summary>
    /// Reloads configuration from file
    /// </summary>
    public void ReloadConfiguration(string configFilePath)
    {
        var newConfig = LoadConfiguration(configFilePath);
        
        // Update current config
        _config.Models.Clear();
        _config.Models.AddRange(newConfig.Models);
        _config.Settings = newConfig.Settings;

        // Recompile patterns
        _compiledPatterns.Clear();
        _compiledPatterns.AddRange(CompilePatterns());
    }

    private double EvaluateModelMatch(string prompt, ModelConfiguration model)
    {
        var matchCount = 0;
        var totalPossibleMatches = model.Heuristics.Keywords.Count + model.Heuristics.Patterns.Count;

        if (totalPossibleMatches == 0)
            return 0;

        var promptToCheck = _config.Settings.CaseSensitive ? prompt : prompt.ToLowerInvariant();

        // Check keywords
        foreach (var keyword in model.Heuristics.Keywords)
        {
            var keywordToCheck = _config.Settings.CaseSensitive ? keyword : keyword.ToLowerInvariant();
            if (promptToCheck.Contains(keywordToCheck))
            {
                matchCount++;
            }
        }

        // Check patterns (if enabled)
        if (_config.Settings.EnablePatternMatching)
        {
            foreach (var pattern in model.Heuristics.Patterns)
            {
                try
                {
                    var regex = new Regex(pattern, _config.Settings.CaseSensitive ? RegexOptions.None : RegexOptions.IgnoreCase);
                    if (regex.IsMatch(prompt))
                    {
                        matchCount++;
                    }
                }
                catch (Exception)
                {
                    // Skip invalid patterns
                    continue;
                }
            }
        }

        // Calculate confidence score
        if (matchCount >= model.Heuristics.MinimumMatches)
        {
            var matchRatio = (double)matchCount / totalPossibleMatches;
            return matchRatio * model.Heuristics.ConfidenceWeight;
        }

        return 0;
    }

    private List<Regex> CompilePatterns()
    {
        var patterns = new List<Regex>();
        var options = _config.Settings.CaseSensitive ? RegexOptions.Compiled : RegexOptions.Compiled | RegexOptions.IgnoreCase;

        foreach (var model in _config.Models)
        {
            foreach (var pattern in model.Heuristics.Patterns)
            {
                try
                {
                    patterns.Add(new Regex(pattern, options));
                }
                catch (Exception)
                {
                    // Skip invalid patterns
                    continue;
                }
            }
        }

        return patterns;
    }

    private static HeuristicConfiguration LoadConfiguration(string configFilePath)
    {
        if (!File.Exists(configFilePath))
            throw new FileNotFoundException($"Configuration file not found: {configFilePath}");

        var json = File.ReadAllText(configFilePath);
        var config = JsonSerializer.Deserialize<HeuristicConfiguration>(json, new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true,
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase
        });

        return config ?? throw new InvalidOperationException("Failed to deserialize configuration");
    }

    private class ModelScore
    {
        public string ModelName { get; set; } = string.Empty;
        public double Score { get; set; }
        public int Priority { get; set; }
    }
}